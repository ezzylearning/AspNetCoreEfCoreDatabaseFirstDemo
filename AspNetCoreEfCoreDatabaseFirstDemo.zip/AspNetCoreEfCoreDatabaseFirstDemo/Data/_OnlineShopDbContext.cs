﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetCoreEfCoreDatabaseFirstDemo.Models;
using Microsoft.EntityFrameworkCore;

namespace AspNetCoreEfCoreDatabaseFirstDemo.Data
{
    public partial class OnlineShopDbContext : DbContext
    {
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>(entity =>
            {
                entity.Property(e => e.Phone).IsRequired();
            });
        }
    }
}
